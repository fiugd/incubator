﻿using System;
using Microsoft.JSInterop;

namespace BasicDotNet
{
    public class BasicDotNet
    {
        public static int Test()
        {
            return 45454545;
        }
        [JSInvokable("Test")]
        public static int Method()
        {
            return 45;
        }
    }
}
